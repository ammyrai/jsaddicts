-------------------------------------------------------
Welcome to ULTRA SEVEN!
-------------------------------------------------------
Contributors: WPoperation
Website: https://wpoperation.com/
Email: support@wpoperation.com
License: GNU General Public License, version 3 (GPLv3)
License URI: http://www.gnu.org/licenses/gpl-3.0.txt
Tags: right-sidebar,left-sidebar,custom-background, custom-menu, featured-images, threaded-comments, translation-ready,custom-logo, footer-widgets,blog,post-formats,sticky-post,theme-options,news
Requires at least: WordPress 4.7
Tested up to: 4.9.7
-------------------------------------------------------
ULTRA SEVEN License
-------------------------------------------------------
Ultra Seven WordPress Theme, Copyright 2018 WPoperation.
Ultra Seven is distributed under the terms of the GNU GPL.

Ultra Seven is based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc.
Underscores is distributed under the terms of the GNU GPL v2 or later.

-------------------------------------------------------
Screenshot Licenses
-------------------------------------------------------
Screenshot images are all licensed under CC0 Universal
https://pixabay.com/en/beautiful-woman-face-young-woman-2150881/
https://pixabay.com/en/beauty-girl-fashion-hat-sexy-863439/
https://pixabay.com/en/feet-legs-standing-waiting-crossed-349687/
https://pixabay.com/en/fashion-sun-hat-sun-protection-985556/
https://pixabay.com/en/person-woman-young-pretty-shoulder-690033/
https://pixabay.com/en/sad-girl-girl-crying-sorrow-actress-1382940/
All other images are designed by WPoperation


-------------------------------------------------------
Normalizing styles
-------------------------------------------------------
Normalizing styles have been helped along thanks to the fine work of.
Nicolas Gallagher and Jonathan Neal http://necolas.github.com/normalize.css/


-------------------------------------------------------
= Elegant Fonts =
-------------------------------------------------------
* Elegant Themes
* https://www.elegantthemes.com/blog/resources/elegant-icon-font
* License: Licensed under MIT
* https://github.com/jonathantneal/flexibility/blob/master/LICENSE.md

-------------------------------------------------------
 = FontAwesome = 
-------------------------------------------------------
* Font Awesome
* License For CSS: Licensed under MIT
* License For Fonts: SIL OFL 1.1
* https://github.com/FortAwesome/Font-Awesome
* https://github.com/FortAwesome/Font-Awesome/blob/master/LICENSE.txt
* http://scripts.sil.org/OFL


-------------------------------------------------------
Light Slider
-------------------------------------------------------
* Sachin N
* License: Licensed under MIT
* https://github.com/sachinchoolur/lightslider
* https://github.com/sachinchoolur/lightslider/blob/master/LICENSE


-------------------------------------------------------
WOW.js
-------------------------------------------------------
* Matt Dellac
* License: GPLV3
* https://github.com/matthieua/WOW
* https://www.gnu.org/licenses/gpl-3.0.en.html


-------------------------------------------------------
FitVids.js
-------------------------------------------------------
* Dave Rupert
* License: Licensed under MIT
* https://github.com/davatron5000/FitVids.js/
* https://opensource.org/licenses/MIT


-------------------------------------------------------
SmoothScroll
-------------------------------------------------------
* License: Licensed under MIT
* https://www.smoothscroll.net/mac/
* https://opensource.org/licenses/MIT

-------------------------------------------------------
Theia Sticky Sidebar
-------------------------------------------------------
* WeCodePixels
* License: Licensed under MIT
* https://github.com/WeCodePixels/theia-sticky-sidebar
* https://github.com/WeCodePixels/theia-sticky-sidebar/blob/master/LICENSE.txt

-------------------------------------------------------
Spectrum
-------------------------------------------------------
* Brian Grinstead
* License: Licensed under MIT
* https://github.com/bgrins/spectrum
* https://github.com/bgrins/spectrum/blob/master/LICENSE


-------------------------------------------------------
Animate.css
-------------------------------------------------------
* Brian Grinstead
* Copyright (c) 2013 Daniel Eden
* License: Licensed under MIT
* https://daneden.github.io/animate.css/
* https://github.com/daneden/animate.css/blob/master/LICENSE


-------------------------------------------------------
= Incorporated Code Copyright Attribution =


* TGM Plugin Activation
* License: GPLV2
* URI: https://opensource.org/licenses/GPL-2.0